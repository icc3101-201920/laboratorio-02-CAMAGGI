﻿using System;

namespace Laboratorio_1_OOP_201902
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
